<div class="header">
	<a href="index.php">Главная</a>
	<a href="riddles.php">Загадки</a>
	<a href="guess.php">Угадайка</a>
	<a href="guess4two.php">Угадайка для двоих</a>
	<a href="passw-generator.php">Генератор паролей</a>
</div>
